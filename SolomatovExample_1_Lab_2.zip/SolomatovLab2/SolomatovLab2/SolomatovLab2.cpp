﻿#include <iostream>
#include <locale.h> //Библиотека для использования setlocale()
#include <stdlib.h>
using namespace std;
int main()
{
	double a, b, P, S;
	setlocale(LC_ALL, "RU"); //Руссификация вывода данных
	cout << "Введите длину прямугольника: ";
	cin >> a;
	cout << "Введите ширину прямугольника: ";
	cin >> b;
	cout << "Периметр прямоугольника: P = 2 * (a + b) = " << 2 * (a + b) << endl;
	cout << "Площадь прямоугольника: S = a * b = " << a * b << endl;
	system("pause");
}